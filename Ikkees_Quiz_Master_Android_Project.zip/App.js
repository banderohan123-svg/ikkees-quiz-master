import React, {useState} from 'react';
import {SafeAreaView, View, Text, TouchableOpacity, ScrollView, StyleSheet, StatusBar} from 'react-native';
const BANK = {
  'सामान्य ज्ञान': [
    {q:'भारत की राजधानी क्या है?',o:['मुंबई','नई दिल्ली','जयपुर','लखनऊ'],a:1},
    {q:'भारत का राष्ट्रीय पशु कौन-सा है?',o:['शेर','हाथी','बाघ','मोर'],a:2},
    {q:'ताजमहल किस शहर में है?',o:['आगरा','दिल्ली','भोपाल','पटना'],a:0},
    {q:'भारत का स्वतंत्रता दिवस कब मनाया जाता है?',o:['26 जनवरी','15 अगस्त','2 अक्टूबर','14 नवंबर'],a:1}
  ],
  'विज्ञान': [
    {q:'पौधे अपना भोजन किस प्रक्रिया से बनाते हैं?',o:['श्वसन','प्रकाश संश्लेषण','वाष्पीकरण','पाचन'],a:1},
    {q:'पानी का रासायनिक सूत्र क्या है?',o:['CO₂','O₂','H₂O','NaCl'],a:2},
    {q:'सौरमंडल का सबसे बड़ा ग्रह कौन-सा है?',o:['पृथ्वी','मंगल','शनि','बृहस्पति'],a:3},
    {q:'मानव शरीर में रक्त पंप करने वाला अंग कौन-सा है?',o:['फेफड़ा','हृदय','यकृत','गुर्दा'],a:1}
  ],
  'गणित': [
    {q:'12 × 8 कितना होता है?',o:['86','92','96','108'],a:2},
    {q:'144 का वर्गमूल क्या है?',o:['10','11','12','14'],a:2},
    {q:'एक त्रिभुज के कोणों का योग कितना होता है?',o:['90°','180°','270°','360°'],a:1},
    {q:'25% का भिन्न रूप क्या है?',o:['1/2','1/3','1/4','1/5'],a:2}
  ]
};
export default function App(){
 const [cat,setCat]=useState(null),[idx,setIdx]=useState(0),[score,setScore]=useState(0),[picked,setPicked]=useState(null),[done,setDone]=useState(false);
 const questions=cat?BANK[cat]:[];
 const reset=()=>{setCat(null);setIdx(0);setScore(0);setPicked(null);setDone(false)};
 const choose=(n)=>{if(picked!==null)return;setPicked(n);if(n===questions[idx].a)setScore(s=>s+1)};
 const next=()=>{if(idx+1===questions.length)setDone(true);else{setIdx(i=>i+1);setPicked(null)}};
 return <SafeAreaView style={s.safe}><StatusBar barStyle="light-content" backgroundColor="#101827"/><ScrollView contentContainerStyle={s.wrap}>
 <Text style={s.brand}>इक्कीस</Text><Text style={s.heading}>QUIZ MASTER</Text>
 {!cat?<><Text style={s.sub}>सीखो • खेलो • अपना स्कोर बढ़ाओ</Text><Text style={s.section}>एक श्रेणी चुनें</Text>{Object.keys(BANK).map(c=><TouchableOpacity key={c} style={s.category} onPress={()=>setCat(c)}><Text style={s.catText}>{c}</Text><Text style={s.arrow}>›</Text></TouchableOpacity>)}<Text style={s.note}>कुल 12 अभ्यास प्रश्न • बिना इंटरनेट और बिना AI</Text></>:
 done?<><Text style={s.section}>क्विज़ पूरा हुआ!</Text><Text style={s.score}>{score} / {questions.length}</Text><Text style={s.sub}>तुम्हारा स्कोर</Text><TouchableOpacity style={s.primary} onPress={reset}><Text style={s.primaryText}>होम पर वापस जाएँ</Text></TouchableOpacity></>:
 <><View style={s.topline}><Text style={s.pill}>{cat}</Text><Text style={s.counter}>{idx+1} / {questions.length}</Text></View><View style={s.progress}><View style={[s.progressFill,{width:`${((idx+1)/questions.length)*100}%`}]}/></View><Text style={s.question}>{questions[idx].q}</Text>{questions[idx].o.map((o,n)=><TouchableOpacity key={n} style={[s.option,picked!==null&&n===questions[idx].a&&s.correct,picked===n&&n!==questions[idx].a&&s.wrong]} onPress={()=>choose(n)}><Text style={s.optionText}>{String.fromCharCode(65+n)}.  {o}</Text></TouchableOpacity>)}{picked!==null&&<><Text style={s.feedback}>{picked===questions[idx].a?'बहुत अच्छे! सही जवाब।':'कोशिश अच्छी थी! सही जवाब: '+questions[idx].o[questions[idx].a]}</Text><TouchableOpacity style={s.primary} onPress={next}><Text style={s.primaryText}>{idx+1===questions.length?'परिणाम देखें':'अगला सवाल'}</Text></TouchableOpacity></>}</>}
 </ScrollView></SafeAreaView>
}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:'#101827'},wrap:{padding:24,paddingTop:45,flexGrow:1},brand:{color:'#7dd3fc',fontSize:18,fontWeight:'800',letterSpacing:2},heading:{color:'#fff',fontSize:30,fontWeight:'900',marginTop:3},sub:{color:'#b8c4d6',fontSize:15,marginTop:12,marginBottom:30},section:{color:'#fff',fontSize:22,fontWeight:'800',marginBottom:18},category:{backgroundColor:'#1d2a3d',padding:20,borderRadius:16,marginBottom:13,flexDirection:'row',justifyContent:'space-between',alignItems:'center',borderWidth:1,borderColor:'#2b3c55'},catText:{color:'#fff',fontSize:18,fontWeight:'700'},arrow:{color:'#7dd3fc',fontSize:28},note:{color:'#8493a8',textAlign:'center',marginTop:22,fontSize:13},topline:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginTop:22},pill:{color:'#7dd3fc',backgroundColor:'#1d2a3d',paddingHorizontal:13,paddingVertical:8,borderRadius:20,fontWeight:'700'},counter:{color:'#cbd5e1'},progress:{height:7,backgroundColor:'#29364a',borderRadius:9,marginTop:18,marginBottom:28},progressFill:{height:7,backgroundColor:'#38bdf8',borderRadius:9},question:{color:'#fff',fontSize:23,fontWeight:'800',lineHeight:34,marginBottom:24},option:{backgroundColor:'#1d2a3d',padding:17,borderRadius:13,marginBottom:12,borderWidth:1,borderColor:'#31435d'},optionText:{color:'#fff',fontSize:16},correct:{borderColor:'#22c55e',backgroundColor:'#123b35'},wrong:{borderColor:'#f87171',backgroundColor:'#40232b'},feedback:{color:'#dbeafe',fontSize:16,marginVertical:18,lineHeight:24},primary:{backgroundColor:'#38bdf8',padding:17,borderRadius:14,alignItems:'center',marginTop:18},primaryText:{color:'#082032',fontWeight:'900',fontSize:16},score:{color:'#7dd3fc',fontSize:58,fontWeight:'900',textAlign:'center',marginTop:20},});
