# इक्कीस Quiz Master

यह एक बेसिक Android क्विज़ ऐप प्रोजेक्ट है। इसमें सामान्य ज्ञान, विज्ञान और गणित के 12 नमूना MCQ हैं। ऐप में AI या बाहरी API नहीं है।

## APK बनाने के लिए
1. इस ZIP को किसी कंप्यूटर पर extract करें।
2. Node.js इंस्टॉल करें और इस फ़ोल्डर में टर्मिनल खोलें।
3. चलाएँ: `npm install`
4. Expo खाते में लॉगिन करें: `npx eas login`
5. EAS CLI इंस्टॉल करें: `npm install -g eas-cli`
6. चलाएँ: `eas build:configure`
7. APK के लिए: `eas build -p android --profile preview`
8. बिल्ड पूरा होने पर EAS डाउनलोड लिंक देगा।

## जरूरी जानकारी
- यह ZIP सोर्स कोड है, APK नहीं।
- Android APK बनाने के लिए EAS Build सेवा और Expo अकाउंट की जरूरत होगी।
- Play Store पर अपलोड करने के लिए production AAB build और Play Console की अलग प्रक्रिया है।
- यह शुरुआती संस्करण है; इसमें अभी लॉगिन, ऑनलाइन लीडरबोर्ड या एडमिन पैनल नहीं है।
